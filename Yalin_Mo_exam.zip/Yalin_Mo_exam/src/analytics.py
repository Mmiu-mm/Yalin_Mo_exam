import os
import time
from pyspark.sql import SparkSession
from pyspark.sql.functions import *

CURATED_PATH = "datalake/curated/domain=iot"
OUTPUT_DIR = "outputs/analytics"
os.makedirs(OUTPUT_DIR, exist_ok=True)

spark = SparkSession.builder \
    .appName("SensorAnalytics") \
    .master("local[*]") \
    .config("spark.sql.adaptive.enabled", "false") \
    .getOrCreate()

if not os.path.exists(CURATED_PATH):
    print(f"ERROR: Curated zone path '{CURATED_PATH}' does not exist.")
    print("Please run the Spark streaming pipeline first and wait for data to be written.")
    spark.stop()
    exit(1)

df = spark.read.parquet(CURATED_PATH)
if df.count() == 0:
    print("WARNING: DataFrame is empty. No data to analyze.")
    spark.stop()
    exit(0)

df.createOrReplaceTempView("sensor_data")

# Query 1: Top 5 hours with highest anomalies
q1 = spark.sql("""
    SELECT hour(event_time) as hour, count(*) as anomaly_count
    FROM sensor_data
    WHERE is_anomaly = true
    GROUP BY hour(event_time)
    ORDER BY anomaly_count DESC
    LIMIT 5
""")
print("=== Top 5 anomaly hours ===")
q1.show()
q1.write.csv(f"{OUTPUT_DIR}/top5_anomaly_hours", header=True, mode="overwrite")

# Query 2: Per sensor type global stats
q2 = spark.sql("""
    SELECT 
        sensor_type,
        round(avg(value),2) as avg_value,
        round(min(value),2) as min_value,
        round(max(value),2) as max_value,
        round(stddev(value),2) as stddev,
        round(100.0 * sum(case when is_anomaly then 1 else 0 end) / count(*),2) as anomaly_rate_pct
    FROM sensor_data
    GROUP BY sensor_type
""")
print("=== Per sensor stats ===")
q2.show()
q2.write.csv(f"{OUTPUT_DIR}/sensor_stats", header=True, mode="overwrite")

# Query 3: Daily evolution for temperature
q3 = spark.sql("""
    SELECT 
        to_date(event_time) as day,
        round(avg(value),2) as mean_temp,
        sum(case when is_anomaly then 1 else 0 end) as anomaly_count
    FROM sensor_data
    WHERE sensor_type = 'temperature'
    GROUP BY to_date(event_time)
    ORDER BY day
""")
print("=== Daily temperature evolution ===")
q3.show()
q3.write.csv(f"{OUTPUT_DIR}/daily_temp_evolution", header=True, mode="overwrite")

# Query 4: Partition pruning demonstration
print("=== Partition pruning demo ===")
start = time.time()
full_count = spark.sql("SELECT COUNT(*) FROM sensor_data").collect()[0][0]
full_time = time.time() - start
print(f"Full scan count: {full_count}, time: {full_time:.2f}s")

start = time.time()
pruned_count = spark.sql("SELECT COUNT(*) FROM sensor_data WHERE sensor_type = 'temperature'").collect()[0][0]
pruned_time = time.time() - start
print(f"Pruned scan count: {pruned_count}, time: {pruned_time:.2f}s")
if pruned_time > 0:
    print(f"Speedup factor: {full_time / pruned_time:.2f}x")
else:
    print("Speedup factor: N/A (pruned time too small)")

spark.stop()