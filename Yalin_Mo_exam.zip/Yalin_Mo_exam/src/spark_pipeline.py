from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

KAFKA_BROKERS = "localhost:9092,localhost:9094,localhost:9096"
TOPIC = "sensor-events"

LAKE_ROOT = "datalake"
RAW_PATH = f"{LAKE_ROOT}/raw/source=kafka/topic=sensor-events"
CURATED_PATH = f"{LAKE_ROOT}/curated/domain=iot"
CONSUMPTION_PATH = f"{LAKE_ROOT}/consumption/use_case=sensor_averages"

CKPT_RAW = "checkpoints/raw"
CKPT_CUR = "checkpoints/curated"
CKPT_CONS = "checkpoints/consumption"

schema = StructType([
    StructField("sensor", StringType(), True),
    StructField("value", DoubleType(), True),
    StructField("unit", StringType(), True),
    StructField("timestamp", LongType(), True),
    StructField("source", StringType(), True),
    StructField("anomaly", BooleanType(), True)
])

spark = SparkSession.builder \
    .appName("SensorETL") \
    .master("local[*]") \
    .config("spark.jars.packages", "org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.3") \
    .config("spark.sql.shuffle.partitions", "3") \
    .config("spark.sql.adaptive.enabled", "false") \
    .getOrCreate()
spark.sparkContext.setLogLevel("WARN")

df_kafka = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", KAFKA_BROKERS) \
    .option("subscribe", TOPIC) \
    .option("startingOffsets", "earliest") \
    .option("failOnDataLoss", "false") \
    .load()

parsed = df_kafka.select(
    from_json(col("value").cast("string"), schema).alias("data"),
    col("value").alias("raw_json"), 
    col("timestamp").alias("kafka_ts")
).select(
    col("data.*"),
    col("raw_json"),
    col("kafka_ts")
).filter(col("sensor").isNotNull())

parsed = parsed.withColumn("event_time", to_timestamp(col("timestamp") / 1000)) \
               .withColumn("ingest_year", year("kafka_ts")) \
               .withColumn("ingest_month", month("kafka_ts")) \
               .withColumn("ingest_day", dayofmonth("kafka_ts")) \
               .withColumn("ingest_hour", hour("kafka_ts"))

validated = parsed.filter(
    ((col("sensor") == "temperature") & (col("value").between(15, 45))) |
    ((col("sensor") == "humidity") & (col("value").between(30, 95))) |
    ((col("sensor") == "pressure") & (col("value").between(980, 1040)))
)

anomaly_condition = (
    ((col("sensor") == "temperature") & (col("value") > 35)) |
    ((col("sensor") == "humidity") & (col("value") > 90)) |
    ((col("sensor") == "pressure") & ((col("value") < 990) | (col("value") > 1030)))
)
validated = validated.withColumn("is_anomaly", anomaly_condition)

watermarked = validated.withWatermark("event_time", "2 minutes")

window_agg = watermarked.groupBy(
    window("event_time", "5 minutes"),
    col("sensor").alias("sensor_type")
).agg(
    avg("value").alias("avg_value"),
    min("value").alias("min_value"),
    max("value").alias("max_value"),
    count("*").alias("record_count"),
    sum(col("is_anomaly").cast("int")).alias("anomaly_count")
)

raw_data = parsed.select(
    col("raw_json").alias("value"), 
    col("kafka_ts").alias("ingestion_ts"),
    col("ingest_year").alias("year"),
    col("ingest_month").alias("month"),
    col("ingest_day").alias("day"),
    col("ingest_hour").alias("hour")
)

curated_data = validated.select(
    "sensor", "value", "unit", "event_time", "source", "anomaly", "is_anomaly",
    year("event_time").alias("year"),
    month("event_time").alias("month"),
    dayofmonth("event_time").alias("day")
).withColumnRenamed("sensor", "sensor_type")

query_raw = raw_data.writeStream \
    .outputMode("append") \
    .format("json") \
    .option("path", RAW_PATH) \
    .option("checkpointLocation", CKPT_RAW) \
    .partitionBy("year", "month", "day", "hour") \
    .trigger(processingTime="30 seconds") \
    .start()

query_curated = curated_data.writeStream \
    .outputMode("append") \
    .format("parquet") \
    .option("path", CURATED_PATH) \
    .option("checkpointLocation", CKPT_CUR) \
    .option("compression", "snappy") \
    .partitionBy("sensor_type", "year", "month", "day") \
    .trigger(processingTime="30 seconds") \
    .start()

query_consumption = window_agg.writeStream \
    .outputMode("append") \
    .format("parquet") \
    .option("path", CONSUMPTION_PATH) \
    .option("checkpointLocation", CKPT_CONS) \
    .option("compression", "snappy") \
    .partitionBy("sensor_type") \
    .trigger(processingTime="30 seconds") \
    .start()

print("All streams started. Press Ctrl+C to terminate.")
spark.streams.awaitAnyTermination()