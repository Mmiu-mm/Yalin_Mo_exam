import argparse
import json
import time
import random
from kafka import KafkaProducer

SENSOR_TYPES = ['temperature', 'humidity', 'pressure']
SENSOR_RANGES = {
    'temperature': (15.0, 45.0),
    'humidity': (30.0, 95.0),
    'pressure': (980.0, 1040.0)
}
UNITS = {'temperature': 'C', 'humidity': '%', 'pressure': 'hPa'}

ANOMALY_THRESHOLDS = {
    'temperature': 35.0,
    'humidity': 90.0,
    'pressure_low': 990.0,
    'pressure_high': 1030.0
}

def generate_reading(sensor_type, source, anomaly_forced=False):
    low, high = SENSOR_RANGES[sensor_type]
    if anomaly_forced:
        if sensor_type == 'temperature':
            value = random.uniform(35.01, high)
        elif sensor_type == 'humidity':
            value = random.uniform(90.01, high)
        elif sensor_type == 'pressure':
            if random.random() < 0.5:
                value = random.uniform(low, 989.99)
            else:
                value = random.uniform(1030.01, high)
        else:
            value = random.uniform(low, high)
    else:
        if sensor_type == 'temperature':
            value = random.uniform(low, 35.0)
        elif sensor_type == 'humidity':
            value = random.uniform(low, 90.0)
        elif sensor_type == 'pressure':
            value = random.uniform(990.0, 1030.0)
        else:
            value = random.uniform(low, high)

    value = round(value, 2)
    return {
        'sensor': sensor_type,
        'value': value,
        'unit': UNITS[sensor_type],
        'timestamp': int(time.time() * 1000),
        'source': source,
        'anomaly': anomaly_forced
    }

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--count', type=int, default=100, help='Number of events')
    parser.add_argument('--rate', type=float, default=5.0, help='Events per second')
    parser.add_argument('--source', type=str, default='simulator', help='Source identifier')
    args = parser.parse_args()

    producer = KafkaProducer(
        bootstrap_servers=['localhost:9092', 'localhost:9094', 'localhost:9096'],
        acks='all',
        retries=5,
        max_in_flight_requests_per_connection=1,
        value_serializer=lambda v: json.dumps(v).encode('utf-8'),
        key_serializer=lambda k: k.encode('utf-8'),
        linger_ms=10,
        batch_size=32768
    )

    interval = 1.0 / args.rate if args.rate > 0 else 0

    try:
        for i in range(args.count):
            sensor = random.choice(SENSOR_TYPES)
            is_anomaly = random.random() < 0.1
            reading = generate_reading(sensor, args.source, anomaly_forced=is_anomaly)
            future = producer.send('sensor-events', key=sensor, value=reading)
            metadata = future.get(timeout=10)
            print(f"[{i+1}/{args.count}] Sent {sensor} value={reading['value']}{reading['unit']} anomaly={is_anomaly} -> partition {metadata.partition}")
            if interval > 0:
                time.sleep(interval)
    except KeyboardInterrupt:
        print("Interrupted")
    finally:
        producer.flush()
        producer.close()

if __name__ == '__main__':
    main()