import os
from datetime import datetime, timedelta, timezone
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, to_date, avg, min, max, expr

CURATED_PATH = "datalake/curated/domain=iot"

_spark = None

def _get_spark():
    global _spark
    if _spark is None:
        _spark = SparkSession.builder \
            .appName("APIHelper") \
            .master("local[2]") \
            .config("spark.sql.adaptive.enabled", "false") \
            .getOrCreate()
    return _spark

def get_sensor_types():
    if not os.path.exists(CURATED_PATH):
        return []
    try:
        subdirs = [d for d in os.listdir(CURATED_PATH) if os.path.isdir(os.path.join(CURATED_PATH, d)) and d.startswith("sensor_type=")]
        types = [d.split("=")[1] for d in subdirs]
        return sorted(types)
    except:
        return []

def get_statistics(sensor_type, days=7):
    spark = _get_spark()
    try:
        df = spark.read.parquet(CURATED_PATH)
        cutoff = datetime.now(timezone.utc) - timedelta(days=days)
        filtered = df.filter(
            (df.sensor_type == sensor_type) &
            (df.event_time >= cutoff)
        )
        daily = filtered.withColumn("date", to_date("event_time")) \
            .groupBy("date") \
            .agg(
                avg("value").alias("avg"),
                min("value").alias("min"),
                max("value").alias("max")
            ) \
            .orderBy("date")
        rows = daily.collect()
        stats = [{"date": str(r.date), "avg": r.avg, "min": r.min, "max": r.max} for r in rows]
        return stats
    except Exception as e:
        print(f"Lake error: {e}")
        return []

def get_anomalies(sensor_type=None, limit=50):
    spark = _get_spark()
    try:
        df = spark.read.parquet(CURATED_PATH)
        filtered = df.filter(df.is_anomaly == True)
        if sensor_type:
            filtered = filtered.filter(df.sensor_type == sensor_type)
        anomalies = filtered.orderBy(col("event_time").desc()) \
            .select("sensor_type", "value", "unit", "event_time", "source") \
            .limit(limit) \
            .collect()
        result = [{"sensor": r.sensor_type, "value": r.value, "unit": r.unit,
                   "timestamp": int(r.event_time.timestamp()*1000), "source": r.source} for r in anomalies]
        return result
    except:
        return []

def close_spark():
    """Optional: call this on API shutdown to release resources."""
    global _spark
    if _spark:
        _spark.stop()
        _spark = None