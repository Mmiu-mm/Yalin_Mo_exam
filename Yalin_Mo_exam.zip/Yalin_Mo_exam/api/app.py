from flask import Flask, jsonify, request
from datetime import datetime, timezone
from kafka_utils import get_latest_readings, publish_reading
from lake_utils import get_statistics, get_sensor_types, get_anomalies
import atexit
from lake_utils import close_spark

app = Flask(__name__)

API_PREFIX = "/api/v1"
VALID_SENSORS = {"temperature", "humidity", "pressure"}

@app.route(f"{API_PREFIX}/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "timestamp": datetime.now(timezone.utc).isoformat()}), 200

@app.route(f"{API_PREFIX}/sensors", methods=["GET"])
def list_sensors():
    sensors = get_sensor_types()
    return jsonify({"status": "success", "data": sensors}), 200

@app.route(f"{API_PREFIX}/sensors/<sensor_type>/latest", methods=["GET"])
def latest_reading(sensor_type):
    if sensor_type not in VALID_SENSORS:
        return jsonify({"status": "error", "message": "Unknown sensor type"}), 404
    readings = get_latest_readings(sensor_type, n=1)
    if not readings:
        return jsonify({"status": "error", "message": "No reading found"}), 404
    return jsonify({"status": "success", "data": readings[0]}), 200

@app.route(f"{API_PREFIX}/sensors/<sensor_type>/stats", methods=["GET"])
def sensor_stats(sensor_type):
    if sensor_type not in VALID_SENSORS:
        return jsonify({"status": "error", "message": "Unknown sensor type"}), 404
    try:
        days = int(request.args.get("days", 7))
        if days < 1 or days > 90:
            raise ValueError
    except:
        return jsonify({"status": "error", "message": "days must be integer 1-90"}), 400
    stats = get_statistics(sensor_type, days)
    return jsonify({"status": "success", "data": stats}), 200

@app.route(f"{API_PREFIX}/anomalies", methods=["GET"])
def anomalies():
    sensor = request.args.get("sensor")
    if sensor and sensor not in VALID_SENSORS:
        return jsonify({"status": "error", "message": "Invalid sensor type"}), 400
    try:
        limit = int(request.args.get("limit", 50))
        if limit < 1 or limit > 200:
            raise ValueError
    except:
        return jsonify({"status": "error", "message": "limit must be 1-200"}), 400
    data = get_anomalies(sensor_type=sensor, limit=limit)
    return jsonify({"status": "success", "data": data}), 200

@app.route(f"{API_PREFIX}/readings", methods=["POST"])
def create_reading():
    body = request.get_json()
    if not body:
        return jsonify({"status": "error", "message": "JSON required"}), 400
    if "sensor" not in body or "value" not in body:
        return jsonify({"status": "error", "message": "Missing sensor or value"}), 400
    if body["sensor"] not in VALID_SENSORS:
        return jsonify({"status": "error", "message": "Invalid sensor type"}), 422
    try:
        value = float(body["value"])
    except:
        return jsonify({"status": "error", "message": "value must be number"}), 422

    reading = {
        "sensor": body["sensor"],
        "value": value,
        "unit": body.get("unit", ""),
        "timestamp": int(datetime.now(timezone.utc).timestamp() * 1000),
        "source": body.get("source", "api"),
        "anomaly": False
    }
    try:
        meta = publish_reading(reading)
        return jsonify({"status": "success", "partition": meta["partition"], "offset": meta["offset"]}), 201
    except:
        return jsonify({"status": "error", "message": "Kafka publish failed"}), 500

@app.errorhandler(404)
def not_found(e):
    return jsonify({"status": "error", "code": 404, "message": "Not found"}), 404

@app.errorhandler(405)
def method_not_allowed(e):
    return jsonify({"status": "error", "code": 405, "message": "Method not allowed"}), 405

@app.errorhandler(500)
def internal_error(e):
    return jsonify({"status": "error", "code": 500, "message": "Internal server error"}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)

atexit.register(close_spark)