from kafka import KafkaConsumer, KafkaProducer
from kafka.structs import TopicPartition
import json

BOOTSTRAP_SERVERS = ['localhost:9092', 'localhost:9094', 'localhost:9096']
TOPIC = 'sensor-events'

def get_latest_readings(sensor_type, n=1, timeout_ms=5000):
    consumer = KafkaConsumer(
        bootstrap_servers=BOOTSTRAP_SERVERS,
        auto_offset_reset='latest',
        enable_auto_commit=False,
        value_deserializer=lambda v: json.loads(v.decode('utf-8')),
        key_deserializer=lambda k: k.decode('utf-8') if k else None,
        consumer_timeout_ms=timeout_ms
    )
    
    partitions = consumer.partitions_for_topic(TOPIC)
    if not partitions:
        consumer.close()
        return []
    
    tp_list = [TopicPartition(TOPIC, p) for p in partitions]
    consumer.assign(tp_list)
    consumer.seek_to_end()
    end_offsets = consumer.end_offsets(tp_list)
    
    readings = []
    max_records_per_partition = max(20, n * 2)
    
    for tp in tp_list:
        start = max(0, end_offsets[tp] - max_records_per_partition)
        if start < end_offsets[tp]:
            consumer.seek(tp, start)
            while len(readings) < n and start < end_offsets[tp]:
                msgs = consumer.poll(timeout_ms=1000, max_records=50)
                if not msgs:
                    break
                for msg in msgs.get(tp, []):
                    if msg.key == sensor_type:
                        readings.append(msg.value)
                        if len(readings) >= n:
                            break
                if msgs:
                    max_offset = max([m.offset for m in msgs.get(tp, [])])
                    start = max_offset + 1
        if len(readings) >= n:
            break
    
    consumer.close()
    readings.sort(key=lambda x: x.get('timestamp', 0), reverse=True)
    return readings[:n]

def publish_reading(reading):
    producer = KafkaProducer(
        bootstrap_servers=BOOTSTRAP_SERVERS,
        acks='all',
        retries=3,
        value_serializer=lambda v: json.dumps(v).encode('utf-8'),
        key_serializer=lambda k: k.encode('utf-8')
    )
    future = producer.send(TOPIC, key=reading['sensor'], value=reading)
    metadata = future.get(timeout=10)
    producer.close()
    return {'partition': metadata.partition, 'offset': metadata.offset}