#!/bin/bash
BASE_URL="http://localhost:5000/api/v1"

echo "=== Health check ==="
curl -s $BASE_URL/health | python -m json.tool

echo -e "\n=== List sensors ==="
curl -s $BASE_URL/sensors | python -m json.tool

echo -e "\n=== Latest temperature ==="
curl -s $BASE_URL/sensors/temperature/latest | python -m json.tool

echo -e "\n=== Stats for humidity (last 3 days) ==="
curl -s "$BASE_URL/sensors/humidity/stats?days=3" | python -m json.tool

echo -e "\n=== Anomalies (limit 5) ==="
curl -s "$BASE_URL/anomalies?limit=5" | python -m json.tool

echo -e "\n=== Post a new reading ==="
curl -s -X POST $BASE_URL/readings \
  -H "Content-Type: application/json" \
  -d '{"sensor":"pressure","value":1012.5,"source":"curl"}' | python -m json.tool

echo -e "\n=== Invalid sensor type (should return 422) ==="
curl -s -X POST $BASE_URL/readings \
  -H "Content-Type: application/json" \
  -d '{"sensor":"co2","value":400}' | python -m json.tool