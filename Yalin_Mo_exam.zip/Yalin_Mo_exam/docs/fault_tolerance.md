# Fault Tolerance Test

## Before stopping broker
$ docker exec kafka1 kafka-topics --bootstrap-server kafka1:29092 --describe --topic sensor-events

Topic: sensor-events TopicId: xxx PartitionCount: 3 ReplicationFactor: 3 Configs: min.insync.replicas=2
Partition: 0 Leader: 1 Replicas: 1,2,3 Isr: 1,2,3
Partition: 1 Leader: 2 Replicas: 1,2,3 Isr: 1,2,3
Partition: 2 Leader: 3 Replicas: 1,2,3 Isr: 1,2,3

## Stop kafka2
docker stop kafka2

## After stopping broker
$ docker exec kafka1 kafka-topics --bootstrap-server kafka1:29092 --describe --topic sensor-events

Topic: sensor-events PartitionCount: 3 ReplicationFactor: 3
Partition: 0 Leader: 1 Replicas: 1,2,3 Isr: 1,3
Partition: 1 Leader: 3 Replicas: 1,2,3 Isr: 1,3
Partition: 2 Leader: 3 Replicas: 1,2,3 Isr: 1,3

**Observation**: Leader re‑election occurred for partitions 1 and 2 (now led by broker 3). ISR list no longer contains broker 2. Topic remains writable/readable because remaining ISR count (2) >= minISR (2).