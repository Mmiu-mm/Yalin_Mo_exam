# Analytical Queries Results

## Query 1 – Top 5 hours with highest anomalies

```sql
SELECT hour(event_time) as hour, COUNT(*) as anomaly_count
FROM curated
WHERE is_anomaly = true
GROUP BY hour(event_time)
ORDER BY anomaly_count DESC
LIMIT 5
Actual result (1000 messages, all produced within hour 9):

hour	anomaly_count
9	109
Query 2 – Per sensor type global stats
SELECT 
    sensor_type,
    round(avg(value),2) as avg_value,
    round(min(value),2) as min_value,
    round(max(value),2) as max_value,
    round(stddev(value),2) as stddev,
    round(100.0 * sum(case when is_anomaly then 1 else 0 end) / count(*),2) as anomaly_rate_pct
FROM sensor_data
GROUP BY sensor_type
Actual results:

sensor_type	avg_value	min_value	max_value	stddev	anomaly_rate_pct
humidity	64.87	30.27	94.82	19.22	13.62
temperature	27.00	15.18	44.70	7.00	7.96
pressure	1008.03	980.36	1039.45	14.02	10.66
Query 3 – Daily evolution for temperature
SELECT 
    to_date(event_time) as day,
    round(avg(value),2) as mean_temp,
    sum(case when is_anomaly then 1 else 0 end) as anomaly_count
FROM sensor_data
WHERE sensor_type = 'temperature'
GROUP BY to_date(event_time)
ORDER BY day
Actual result (data from 2026-05-19 only):

day	mean_temp	anomaly_count
2026-05-19	27.00	25
Partition Pruning Demonstration
-- Full scan (no filter)
SELECT COUNT(*) FROM sensor_data

-- Pruned scan (filter on partition column sensor_type)
SELECT COUNT(*) FROM sensor_data WHERE sensor_type = 'temperature'
Measured times:

Query	Time (seconds)
Full scan	0.16
Pruned scan	0.09
Speedup factor	1.85x
Partition pruning reduces I/O by scanning only directories matching sensor_type=temperature.
All CSV outputs are saved in outputs/analytics/:

top5_anomaly_hours/

sensor_stats/

daily_temp_evolution/

---