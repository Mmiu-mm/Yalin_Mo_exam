\# Reflection Questions



\## 1. Crash after raw zone but before curated – impact and checkpoint strategy



\*\*Impact\*\*: Raw JSON files exist, but curated Parquet files are missing. Any downstream consumer (API, analytics) that relies on curated data would see stale or incomplete results. However, the raw zone preserves the original data, so no information is lost.



\*\*Checkpoint strategy\*\*: Each sink in Spark Structured Streaming has its own checkpoint directory. If the streaming job crashes after writing to raw but before curated, the checkpoint for the curated sink will still point to the last committed Kafka offset before the crash. Upon restart, Spark will replay only the data that was not successfully written to curated, because the raw sink’s checkpoint may already have advanced. This prevents data loss for the curated zone. To be fully safe, we also configure `failOnDataLoss=false` to avoid unnecessary crashes when offsets are out of range.



\## 2. Scaling to 50,000 messages/sec – bottlenecks and fixes



\*\*First bottlenecks\*\*:

\- \*\*Kafka\*\*: Network bandwidth and disk I/O on a single broker. With 3 partitions, parallelism is limited.

\- \*\*Spark\*\*: Running in `local\[\*]` mode on a single machine – the driver and executors compete for CPU/memory.

\- \*\*Data lake\*\*: Writing many small Parquet files per micro-batch (default partitionBy creates many files, hurting HDFS/cloud storage).



\*\*Fixes\*\*:

\- Increase Kafka partitions to at least 12 and add more brokers (e.g., 6) to distribute load.

\- Deploy Spark in cluster mode on 3–5 worker nodes, increase shuffle partitions to 2× cores.

\- Use `coalesce()` or `repartition()` to reduce output file count, or switch to Delta Lake for optimized writes.

\- Tune producer `linger.ms` and `batch.size` to increase throughput at the cost of latency.



\## 3. Kafka vs Parquet data lake as source of truth



| Aspect | Kafka | Parquet data lake |

|--------|-------|-------------------|

| \*\*Real-time\*\* | Excellent (millisecond latency) | Poor (batch-oriented) |

| \*\*Historical analytics\*\* | Expensive to replay, retention limited | Efficient columnar storage, compression, partition pruning |

| \*\*Schema evolution\*\* | Requires compatibility handling | Easy (schema on read) |

| \*\*Durability\*\* | Retention-based deletion | Permanent (until manually deleted) |

| \*\*Use cases\*\* | Streaming dashboards, alerts, real-time features | ML training, long-term trend analysis, ad-hoc SQL |



\*\*Prefer Kafka\*\* when latency < 1 second and data is only needed for a few days.  

\*\*Prefer Parquet\*\* when data must be kept for months/years and queried with complex aggregations.



\## 4. Sensor emitting aberrant values for 2 hours – detection and isolation



\*\*Detection\*\*: The anomaly detection rule in Spark (temp > 35°C OR humidity > 90% OR pressure < 990 OR > 1030 hPa) will mark those values as `is\_anomaly = true`. The rule is applied independently of the producer’s self‑declared `anomaly` flag, so even if the sensor itself doesn’t report an anomaly, the pipeline will flag it.



\*\*Isolation without deletion\*\*:

\- Keep all data in the curated zone, but downstream queries can filter `WHERE is\_anomaly = false` for normal analysis.

\- For investigation, create a separate “quality” view that includes anomalies, or store them in a dedicated anomaly table.

\- Optionally, trigger an alert when the anomaly rate exceeds a threshold (e.g., >20% over 5 minutes).



\## 5. Adding a new sensor type `co2` – required changes



| File | Changes |

|------|---------|

| `src/producer.py` | Add `'co2'` to `SENSOR\_TYPES`, define `SENSOR\_RANGES\['co2'] = (300, 2000)`, `UNITS\['co2'] = 'ppm'`, and extend `generate\_reading()` to handle CO₂ anomalies (e.g., >1000 ppm). |

| `src/spark\_pipeline.py` | Extend the anomaly condition: `((col("sensor") == "co2") \& (col("value") > 1000))`. Also add CO₂ to the validation filter: `(col("sensor") == "co2") \& (col("value").between(300, 2000))`. |

| `api/app.py` | Add `'co2'` to `VALID\_SENSORS` set. |

| `api/lake\_utils.py` | No change – Spark schema inference will automatically handle the new type in Parquet files. |

| `src/analytics.py` | No code change – queries group by `sensor\_type` and will include CO₂ automatically. |

| `docs/\*.md` | Update architecture diagrams and examples to mention CO₂. |

