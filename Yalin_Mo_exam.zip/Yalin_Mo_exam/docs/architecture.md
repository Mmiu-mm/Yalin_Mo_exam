# Architecture Overview

## Pipeline Diagram
[IoT Simulator] -> [Kafka (sensor‑events)] -> [Spark Streaming] -> [Data Lake (Parquet/JSON)] -> [REST API] -> [Client]
| |
+-----> [Analytics] ---+

## Components

- **Kafka**  
  - 3 brokers, RF=3, minISR=2.  
  - Topic `sensor-events` with 3 partitions, keyed by sensor_type.

- **Spark Structured Streaming**  
  - Reads from Kafka, parses JSON, validates outliers.  
  - Detects anomalies independently (temp>35°C or humidity>90% or pressure out of [990,1030]).  
  - Applies 2‑minute watermark on event_time.  
  - 5‑minute tumbling windows, computes avg/min/max/count/anomaly_count.  
  - Three‑zone write:

| Zone        | Format   | Partitioning                                  | Path (relative to project root) |
|-------------|----------|-----------------------------------------------|----------------------------------|
| raw         | JSON     | ingestion year/month/day/hour                 | `datalake/raw/source=kafka/topic=sensor-events/` |
| curated     | Parquet  | sensor_type / event_time year/month/day       | `datalake/curated/domain=iot/` |
| consumption | Parquet  | sensor_type                                    | `datalake/consumption/use_case=sensor_averages/` |

- **Analytics**  
  - Spark SQL batch queries on curated zone.  
  - Partition pruning demonstration with speedup factor.

- **REST API** (Flask)  
  - Endpoints: `/health`, `/sensors`, `/sensors/<type>/latest`, `/sensors/<type>/stats`, `/anomalies`, `/readings`.  
  - Input validation, correct HTTP status codes.

## Technical Choices (justification)

### Partitioning strategy for curated zone
`sensor_type/year/month/day` – enables fast filtering by sensor type and time, reduces scan for analytics queries.

### Spark outputMode
`append` – because watermark ensures late data is discarded; window results are final and never updated.

### Replication factor (3) and min.insync.replicas (2)
Provides fault tolerance: with 3 brokers, the cluster remains available if one broker fails. minISR=2 guarantees no data loss before acknowledging writes.

### event_time vs ingestion_time
- Raw zone uses **ingestion_time** (Kafka timestamp) for simple log‑style storage.  
- Curated and consumption zones use **event_time** (sensor timestamp) to respect business time, essential for correct windowing and late data handling.

### End‑to‑end semantics
At‑least‑once: Kafka producer `acks=all` + Spark checkpointing may cause duplicates during failures. Exactly‑once would require idempotent writes and transactional sinks, which adds complexity. Our pipeline prioritises reliability over absolute exactly‑once.